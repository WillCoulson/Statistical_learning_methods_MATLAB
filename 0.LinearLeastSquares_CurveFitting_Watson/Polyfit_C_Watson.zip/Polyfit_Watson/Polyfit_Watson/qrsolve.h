/*
 * File: qrsolve.h
 *
 * MATLAB Coder version            : 4.3
 * C/C++ source code generated on  : 29-Nov-2020 12:43:08
 */

#ifndef QRSOLVE_H
#define QRSOLVE_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "Polyfit_Watson_types.h"

/* Function Declarations */
extern void qrsolve(const emxArray_real_T *A, const emxArray_real_T *B,
                    emxArray_real_T *Y);

#endif

/*
 * File trailer for qrsolve.h
 *
 * [EOF]
 */
