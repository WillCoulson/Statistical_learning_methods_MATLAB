/*
 * File: Polyfit_Watson.h
 *
 * MATLAB Coder version            : 4.3
 * C/C++ source code generated on  : 29-Nov-2020 12:43:08
 */

#ifndef POLYFIT_WATSON_H
#define POLYFIT_WATSON_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "Polyfit_Watson_types.h"

/* Function Declarations */
extern void Polyfit_Watson(const emxArray_real_T *fit_x, const emxArray_real_T
  *fit_y, double n, emxArray_real_T *p);

#endif

/*
 * File trailer for Polyfit_Watson.h
 *
 * [EOF]
 */
