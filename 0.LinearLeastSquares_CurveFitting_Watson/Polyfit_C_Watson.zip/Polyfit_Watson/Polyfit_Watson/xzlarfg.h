/*
 * File: xzlarfg.h
 *
 * MATLAB Coder version            : 4.3
 * C/C++ source code generated on  : 29-Nov-2020 12:43:08
 */

#ifndef XZLARFG_H
#define XZLARFG_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "Polyfit_Watson_types.h"

/* Function Declarations */
extern double xzlarfg(int n, double *alpha1, emxArray_real_T *x, int ix0);

#endif

/*
 * File trailer for xzlarfg.h
 *
 * [EOF]
 */
