/*
 * File: qr.h
 *
 * MATLAB Coder version            : 4.3
 * C/C++ source code generated on  : 29-Nov-2020 12:43:08
 */

#ifndef QR_H
#define QR_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "Polyfit_Watson_types.h"

/* Function Declarations */
extern void qr(const emxArray_real_T *A, emxArray_real_T *Q, emxArray_real_T *R);

#endif

/*
 * File trailer for qr.h
 *
 * [EOF]
 */
