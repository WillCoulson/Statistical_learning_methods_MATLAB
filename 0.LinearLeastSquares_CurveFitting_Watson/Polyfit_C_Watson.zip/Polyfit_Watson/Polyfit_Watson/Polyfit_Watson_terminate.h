/*
 * File: Polyfit_Watson_terminate.h
 *
 * MATLAB Coder version            : 4.3
 * C/C++ source code generated on  : 29-Nov-2020 12:43:08
 */

#ifndef POLYFIT_WATSON_TERMINATE_H
#define POLYFIT_WATSON_TERMINATE_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "Polyfit_Watson_types.h"

/* Function Declarations */
extern void Polyfit_Watson_terminate(void);

#endif

/*
 * File trailer for Polyfit_Watson_terminate.h
 *
 * [EOF]
 */
