/*
 * File: Polyfit_Watson_initialize.c
 *
 * MATLAB Coder version            : 4.3
 * C/C++ source code generated on  : 29-Nov-2020 12:43:08
 */

/* Include Files */
#include "Polyfit_Watson_initialize.h"
#include "Polyfit_Watson.h"
#include "Polyfit_Watson_data.h"
#include "rt_nonfinite.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void Polyfit_Watson_initialize(void)
{
  rt_InitInfAndNaN();
  isInitialized_Polyfit_Watson = true;
}

/*
 * File trailer for Polyfit_Watson_initialize.c
 *
 * [EOF]
 */
