/*
 * File: Polyfit_Watson.c
 *
 * MATLAB Coder version            : 4.3
 * C/C++ source code generated on  : 29-Nov-2020 12:43:08
 */

/* Include Files */
#include "Polyfit_Watson.h"
#include "Polyfit_Watson_data.h"
#include "Polyfit_Watson_emxutil.h"
#include "Polyfit_Watson_initialize.h"
#include "qr.h"
#include "qrsolve.h"
#include "rt_nonfinite.h"
#include <math.h>

/* Function Definitions */

/*
 * Arguments    : const emxArray_real_T *fit_x
 *                const emxArray_real_T *fit_y
 *                double n
 *                emxArray_real_T *p
 * Return Type  : void
 */
void Polyfit_Watson(const emxArray_real_T *fit_x, const emxArray_real_T *fit_y,
                    double n, emxArray_real_T *p)
{
  emxArray_real_T *x;
  int i;
  int m;
  emxArray_real_T *V;
  int k;
  emxArray_real_T *b_x;
  int j;
  emxArray_real_T *Q;
  double smax;
  emxArray_real_T *R;
  int aoffset;
  int inner;
  int b_i;
  emxArray_int32_T *ipiv;
  int b_n;
  int ldap1;
  int u1;
  int mmj_tmp;
  int jj;
  int ix;
  double s;
  if (isInitialized_Polyfit_Watson == false) {
    Polyfit_Watson_initialize();
  }

  emxInit_real_T(&x, 1);
  i = x->size[0];
  x->size[0] = fit_x->size[1];
  emxEnsureCapacity_real_T(x, i);
  m = fit_x->size[1];
  for (i = 0; i < m; i++) {
    x->data[i] = fit_x->data[i];
  }

  emxInit_real_T(&V, 2);
  i = V->size[0] * V->size[1];
  V->size[0] = x->size[0];
  k = (int)(n + 1.0);
  V->size[1] = k;
  emxEnsureCapacity_real_T(V, i);
  m = x->size[0] * k;
  for (i = 0; i < m; i++) {
    V->data[i] = 1.0;
  }

  /*  Construct the Vandermonde matrix V = [x.^n ... x.^2 x ones(size(x))] */
  m = x->size[0];
  for (i = 0; i < m; i++) {
    V->data[i + V->size[0] * (k - 1)] = 1.0;
  }

  i = (int)(((-1.0 - n) + 1.0) / -1.0);
  emxInit_real_T(&b_x, 1);
  for (j = 0; j < i; j++) {
    smax = n + -(double)j;
    m = x->size[0];
    k = b_x->size[0];
    b_x->size[0] = x->size[0];
    emxEnsureCapacity_real_T(b_x, k);
    for (k = 0; k < m; k++) {
      b_x->data[k] = x->data[k] * V->data[k + V->size[0] * (int)smax];
    }

    m = b_x->size[0];
    for (k = 0; k < m; k++) {
      V->data[k + V->size[0] * ((int)smax - 1)] = b_x->data[k];
    }
  }

  emxInit_real_T(&Q, 2);
  emxInit_real_T(&R, 2);

  /*  ������С���˷����ʵ�ֵĺ���  */
  qr(V, Q, R);

  /*  ������С���˷����ʵ�ֵĺ���  */
  i = V->size[0] * V->size[1];
  V->size[0] = Q->size[1];
  V->size[1] = Q->size[0];
  emxEnsureCapacity_real_T(V, i);
  m = Q->size[0];
  for (i = 0; i < m; i++) {
    aoffset = Q->size[1];
    for (k = 0; k < aoffset; k++) {
      V->data[k + V->size[0] * i] = Q->data[i + Q->size[0] * k];
    }
  }

  emxFree_real_T(&Q);
  i = x->size[0];
  x->size[0] = fit_y->size[1];
  emxEnsureCapacity_real_T(x, i);
  m = fit_y->size[1];
  for (i = 0; i < m; i++) {
    x->data[i] = fit_y->data[i];
  }

  if ((V->size[1] == 1) || (x->size[0] == 1)) {
    i = b_x->size[0];
    b_x->size[0] = V->size[0];
    emxEnsureCapacity_real_T(b_x, i);
    m = V->size[0];
    for (i = 0; i < m; i++) {
      b_x->data[i] = 0.0;
      aoffset = V->size[1];
      for (k = 0; k < aoffset; k++) {
        b_x->data[i] += V->data[i + V->size[0] * k] * x->data[k];
      }
    }
  } else {
    m = V->size[0];
    inner = V->size[1];
    i = b_x->size[0];
    b_x->size[0] = V->size[0];
    emxEnsureCapacity_real_T(b_x, i);
    for (b_i = 0; b_i < m; b_i++) {
      b_x->data[b_i] = 0.0;
    }

    for (k = 0; k < inner; k++) {
      aoffset = k * m;
      for (b_i = 0; b_i < m; b_i++) {
        b_x->data[b_i] += x->data[k] * V->data[aoffset + b_i];
      }
    }
  }

  emxFree_real_T(&V);
  emxInit_int32_T(&ipiv, 2);
  if ((R->size[0] == 0) || (R->size[1] == 0) || (b_x->size[0] == 0)) {
    i = x->size[0];
    x->size[0] = R->size[1];
    emxEnsureCapacity_real_T(x, i);
    m = R->size[1];
    for (i = 0; i < m; i++) {
      x->data[i] = 0.0;
    }
  } else if (R->size[0] == R->size[1]) {
    b_n = R->size[1];
    m = R->size[1];
    i = ipiv->size[0] * ipiv->size[1];
    ipiv->size[0] = 1;
    ipiv->size[1] = R->size[1];
    emxEnsureCapacity_int32_T(ipiv, i);
    ipiv->data[0] = 1;
    aoffset = 1;
    for (k = 2; k <= m; k++) {
      aoffset++;
      ipiv->data[k - 1] = aoffset;
    }

    ldap1 = R->size[1];
    aoffset = R->size[1] - 1;
    u1 = R->size[1];
    if (aoffset < u1) {
      u1 = aoffset;
    }

    for (j = 0; j < u1; j++) {
      mmj_tmp = b_n - j;
      m = j * (b_n + 1);
      jj = j * (ldap1 + 1);
      inner = m + 2;
      if (mmj_tmp < 1) {
        aoffset = -1;
      } else {
        aoffset = 0;
        if (mmj_tmp > 1) {
          ix = m;
          smax = fabs(R->data[jj]);
          for (k = 2; k <= mmj_tmp; k++) {
            ix++;
            s = fabs(R->data[ix]);
            if (s > smax) {
              aoffset = k - 1;
              smax = s;
            }
          }
        }
      }

      if (R->data[jj + aoffset] != 0.0) {
        if (aoffset != 0) {
          aoffset += j;
          ipiv->data[j] = aoffset + 1;
          ix = j;
          for (k = 0; k < b_n; k++) {
            smax = R->data[ix];
            R->data[ix] = R->data[aoffset];
            R->data[aoffset] = smax;
            ix += b_n;
            aoffset += b_n;
          }
        }

        i = jj + mmj_tmp;
        for (b_i = inner; b_i <= i; b_i++) {
          R->data[b_i - 1] /= R->data[jj];
        }
      }

      aoffset = m + b_n;
      m = jj + ldap1;
      for (inner = 0; inner <= mmj_tmp - 2; inner++) {
        smax = R->data[aoffset];
        if (R->data[aoffset] != 0.0) {
          ix = jj + 1;
          i = m + 2;
          k = mmj_tmp + m;
          for (b_i = i; b_i <= k; b_i++) {
            R->data[b_i - 1] += R->data[ix] * -smax;
            ix++;
          }
        }

        aoffset += b_n;
        m += b_n;
      }
    }

    i = x->size[0];
    x->size[0] = b_x->size[0];
    emxEnsureCapacity_real_T(x, i);
    m = b_x->size[0];
    for (i = 0; i < m; i++) {
      x->data[i] = b_x->data[i];
    }

    for (aoffset = 0; aoffset <= b_n - 2; aoffset++) {
      i = ipiv->data[aoffset];
      if (i != aoffset + 1) {
        smax = x->data[aoffset];
        x->data[aoffset] = x->data[i - 1];
        x->data[i - 1] = smax;
      }
    }

    for (k = 0; k < b_n; k++) {
      aoffset = b_n * k;
      if (x->data[k] != 0.0) {
        i = k + 2;
        for (b_i = i; b_i <= b_n; b_i++) {
          x->data[b_i - 1] -= x->data[k] * R->data[(b_i + aoffset) - 1];
        }
      }
    }

    for (k = b_n; k >= 1; k--) {
      aoffset = b_n * (k - 1);
      smax = x->data[k - 1];
      if (smax != 0.0) {
        x->data[k - 1] = smax / R->data[(k + aoffset) - 1];
        for (b_i = 0; b_i <= k - 2; b_i++) {
          x->data[b_i] -= x->data[k - 1] * R->data[b_i + aoffset];
        }
      }
    }
  } else {
    qrsolve(R, b_x, x);
  }

  emxFree_real_T(&b_x);
  emxFree_int32_T(&ipiv);
  emxFree_real_T(&R);

  /*  Same as p = V\y */
  i = p->size[0] * p->size[1];
  p->size[0] = 1;
  p->size[1] = x->size[0];
  emxEnsureCapacity_real_T(p, i);
  m = x->size[0];
  for (i = 0; i < m; i++) {
    p->data[i] = x->data[i];
  }

  emxFree_real_T(&x);

  /*  Polynomial coefficients are row vectors by convention. */
}

/*
 * File trailer for Polyfit_Watson.c
 *
 * [EOF]
 */
