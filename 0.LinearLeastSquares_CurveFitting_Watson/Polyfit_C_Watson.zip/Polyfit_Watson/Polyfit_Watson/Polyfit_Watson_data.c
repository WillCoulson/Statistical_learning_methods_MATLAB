/*
 * File: Polyfit_Watson_data.c
 *
 * MATLAB Coder version            : 4.3
 * C/C++ source code generated on  : 29-Nov-2020 12:43:08
 */

/* Include Files */
#include "Polyfit_Watson_data.h"
#include "Polyfit_Watson.h"
#include "rt_nonfinite.h"

/* Variable Definitions */
boolean_T isInitialized_Polyfit_Watson = false;

/*
 * File trailer for Polyfit_Watson_data.c
 *
 * [EOF]
 */
