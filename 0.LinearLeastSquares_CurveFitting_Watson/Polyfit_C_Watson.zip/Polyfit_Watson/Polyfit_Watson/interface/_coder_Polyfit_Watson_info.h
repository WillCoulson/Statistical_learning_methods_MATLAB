/*
 * File: _coder_Polyfit_Watson_info.h
 *
 * MATLAB Coder version            : 4.3
 * C/C++ source code generated on  : 29-Nov-2020 12:43:08
 */

#ifndef _CODER_POLYFIT_WATSON_INFO_H
#define _CODER_POLYFIT_WATSON_INFO_H

/* Include Files */
#include "mex.h"

/* Function Declarations */
MEXFUNCTION_LINKAGE mxArray *emlrtMexFcnProperties(void);

#endif

/*
 * File trailer for _coder_Polyfit_Watson_info.h
 *
 * [EOF]
 */
