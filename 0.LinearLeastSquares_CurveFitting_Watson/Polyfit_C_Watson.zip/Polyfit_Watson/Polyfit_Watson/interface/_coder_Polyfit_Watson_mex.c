/*
 * File: _coder_Polyfit_Watson_mex.c
 *
 * MATLAB Coder version            : 4.3
 * C/C++ source code generated on  : 29-Nov-2020 12:43:08
 */

/* Include Files */
#include "_coder_Polyfit_Watson_mex.h"
#include "_coder_Polyfit_Watson_api.h"

/* Function Declarations */
MEXFUNCTION_LINKAGE void Polyfit_Watson_mexFunction(int32_T nlhs, mxArray *plhs
  [1], int32_T nrhs, const mxArray *prhs[3]);

/* Function Definitions */

/*
 * Arguments    : int32_T nlhs
 *                mxArray *plhs[1]
 *                int32_T nrhs
 *                const mxArray *prhs[3]
 * Return Type  : void
 */
void Polyfit_Watson_mexFunction(int32_T nlhs, mxArray *plhs[1], int32_T nrhs,
  const mxArray *prhs[3])
{
  const mxArray *outputs[1];
  emlrtStack st = { NULL,              /* site */
    NULL,                              /* tls */
    NULL                               /* prev */
  };

  st.tls = emlrtRootTLSGlobal;

  /* Check for proper number of arguments. */
  if (nrhs != 3) {
    emlrtErrMsgIdAndTxt(&st, "EMLRT:runTime:WrongNumberOfInputs", 5, 12, 3, 4,
                        14, "Polyfit_Watson");
  }

  if (nlhs > 1) {
    emlrtErrMsgIdAndTxt(&st, "EMLRT:runTime:TooManyOutputArguments", 3, 4, 14,
                        "Polyfit_Watson");
  }

  /* Call the function. */
  Polyfit_Watson_api(prhs, nlhs, outputs);

  /* Copy over outputs to the caller. */
  emlrtReturnArrays(1, plhs, outputs);
}

/*
 * Arguments    : int32_T nlhs
 *                mxArray *plhs[]
 *                int32_T nrhs
 *                const mxArray *prhs[]
 * Return Type  : void
 */
void mexFunction(int32_T nlhs, mxArray *plhs[], int32_T nrhs, const mxArray
                 *prhs[])
{
  mexAtExit(Polyfit_Watson_atexit);

  /* Module initialization. */
  Polyfit_Watson_initialize();

  /* Dispatch the entry-point. */
  Polyfit_Watson_mexFunction(nlhs, plhs, nrhs, prhs);

  /* Module termination. */
  Polyfit_Watson_terminate();
}

/*
 * Arguments    : void
 * Return Type  : emlrtCTX
 */
emlrtCTX mexFunctionCreateRootTLS(void)
{
  emlrtCreateRootTLS(&emlrtRootTLSGlobal, &emlrtContextGlobal, NULL, 1);
  return emlrtRootTLSGlobal;
}

/*
 * File trailer for _coder_Polyfit_Watson_mex.c
 *
 * [EOF]
 */
